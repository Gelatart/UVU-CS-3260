﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LabPhase3
{
    class Course
    {
        //figure out if going to use this at some point
    }
}
